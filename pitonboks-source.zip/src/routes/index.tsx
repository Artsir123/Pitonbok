import { createFileRoute } from "@tanstack/react-router";
import { Playground } from "@/playground/playground";

export const Route = createFileRoute("/")({ component: Playground });
