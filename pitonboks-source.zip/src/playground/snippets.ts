export type Snippet = {
  id: string;
  title: string;
  blurb: string;
  code: string;
};

export const snippets: Snippet[] = [
  {
    id: "hello",
    title: "Приветствие",
    blurb: "цикл и f-строки",
    code: `print("Привет из Питонбокса")

items = ["чай", "код", "вечер"]
for number, item in enumerate(items, start=1):
    print(f"{number}. {item}")

print("Звёзды:")
for count in range(1, 6):
    print("#" * count)
`,
  },
  {
    id: "password",
    title: "Пароль",
    blurb: "secrets из стандартной библиотеки",
    code: `import secrets
import string

alphabet = string.ascii_letters + string.digits
password = "".join(secrets.choice(alphabet) for _ in range(14))
print(password)
`,
  },
  {
    id: "budget",
    title: "Бюджет",
    blurb: "сумма и полоски",
    code: `expenses = {
    "кофе": 840,
    "метро": 560,
    "обед": 2100,
    "книги": 690,
}

total = sum(expenses.values())
print(f"Всего за неделю: {total} руб.")
print()

for name, amount in sorted(expenses.items(), key=lambda item: -item[1]):
    bar = "#" * max(1, amount // 200)
    print(f"{name:<8} {bar}  {amount}")
`,
  },
  {
    id: "fizzbuzz",
    title: "FizzBuzz",
    blurb: "классика на 20 чисел",
    code: `def fizzbuzz(limit):
    words = []
    for number in range(1, limit + 1):
        if number % 15 == 0:
            words.append("FizzBuzz")
        elif number % 3 == 0:
            words.append("Fizz")
        elif number % 5 == 0:
            words.append("Buzz")
        else:
            words.append(str(number))
    return words

print(" ".join(fizzbuzz(20)))
`,
  },
  {
    id: "primes",
    title: "Простые",
    blurb: "решето Эратосфена",
    code: `def primes_up_to(limit):
    sieve = [True] * (limit + 1)
    sieve[0:2] = [False, False]
    for number in range(2, int(limit**0.5) + 1):
        if sieve[number]:
            start = number * number
            sieve[start::number] = [False] * len(sieve[start::number])
    return [number for number, ok in enumerate(sieve) if ok]

found = primes_up_to(80)
print("Простые до 80:")
print(", ".join(map(str, found)))
print("Всего:", len(found))
`,
  },
  {
    id: "degrees",
    title: "Градусы",
    blurb: "Цельсий в Фаренгейт",
    code: `def celsius_to_fahrenheit(celsius):
    return celsius * 9 / 5 + 32

print(f"{'C':>6} {'F':>8}")
for celsius in range(-10, 35, 5):
    fahrenheit = celsius_to_fahrenheit(celsius)
    print(f"{celsius:>6} {fahrenheit:>8.1f}")
`,
  },
];

export const defaultSnippet = snippets[0];
