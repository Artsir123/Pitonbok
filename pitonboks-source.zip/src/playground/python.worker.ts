import { loadPyodide, type PyodideInterface } from "pyodide";

type RunRequest = {
  id: number;
  code: string;
  indexURL: string;
};

type RunResponse =
  | { id: number; phase: "loading" | "running" }
  | { id: number; phase: "done"; stdout: string; stderr: string };

const HARNESS = `
import traceback
from io import StringIO
import sys

_MAX = 12000

def __pitonbox_run(src):
    stdout, stderr = StringIO(), StringIO()
    old_out, old_err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = stdout, stderr
    try:
        code = compile(src, "<питонбокс>", "exec")
        sandbox = {"__name__": "__main__"}
        exec(code, sandbox, sandbox)
    except SystemExit as exc:
        if exc.code not in (None, 0):
            print("Выход с кодом %s" % (exc.code,), file=stderr)
    except Exception:
        err_type, exc, tb = sys.exc_info()
        frames = [
            frame
            for frame in traceback.extract_tb(tb)
            if frame.filename == "<питонбокс>"
        ]
        stderr.write("".join(traceback.format_list(frames)))
        stderr.write("".join(traceback.format_exception_only(err_type, exc)))
    finally:
        sys.stdout, sys.stderr = old_out, old_err
    out = stdout.getvalue()
    err = stderr.getvalue()
    if len(out) > _MAX:
        out = out[:_MAX] + "\\n… вывод обрезан\\n"
    if len(err) > _MAX:
        err = err[:_MAX] + "\\n… вывод обрезан\\n"
    return out, err
`;

let runtime: PyodideInterface | null = null;
let chain: Promise<void> = Promise.resolve();

interface WorkerScope {
  onmessage: ((event: MessageEvent<RunRequest>) => void) | null;
  postMessage: (message: RunResponse) => void;
}

const scope = globalThis as unknown as WorkerScope;

async function ensureRuntime(indexURL: string) {
  if (!runtime) {
    runtime = await loadPyodide({ indexURL });
    await runtime.runPythonAsync(HARNESS);
  }
  return runtime;
}

scope.onmessage = (event: MessageEvent<RunRequest>) => {
  const { id, code, indexURL } = event.data;
  chain = chain.then(async () => {
    try {
      if (!runtime) scope.postMessage({ id, phase: "loading" } satisfies RunResponse);
      const py = await ensureRuntime(indexURL);
      scope.postMessage({ id, phase: "running" } satisfies RunResponse);
      py.globals.set("__src", code);
      const result = await py.runPythonAsync("__pitonbox_run(__src)");
      const pair = result.toJs() as [string, string];
      result.destroy();
      const message: RunResponse = {
        id,
        phase: "done",
        stdout: pair[0] ?? "",
        stderr: pair[1] ?? "",
      };
      scope.postMessage(message);
    } catch (error) {
      const message: RunResponse = {
        id,
        phase: "done",
        stdout: "",
        stderr: error instanceof Error ? error.message : String(error),
      };
      scope.postMessage(message);
    }
  });
};
