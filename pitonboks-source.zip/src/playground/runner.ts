import { previewPathPrefix } from "@/lib/preview-path-prefix";

export type RunPhase = "loading" | "running" | "done";

export type RunResult = {
  stdout: string;
  stderr: string;
  stopped: boolean;
};

type WorkerResponse =
  | { id: number; phase: "loading" | "running" }
  | { id: number; phase: "done"; stdout: string; stderr: string };

const RUN_LIMIT_MS = 8000;
const LOAD_LIMIT_MS = 45000;

let worker: Worker | null = null;
let nextId = 1;

function pyodideIndexUrl(): string {
  const prefix =
    previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
  return `${window.location.origin}${prefix}/pyodide/`;
}

function spawnWorker() {
  worker?.terminate();
  worker = new Worker(new URL("./python.worker.ts", import.meta.url), {
    type: "module",
  });
  return worker;
}

export function runPython(
  code: string,
  onPhase: (phase: RunPhase) => void,
): Promise<RunResult> {
  const current = worker ?? spawnWorker();
  const id = nextId++;

  return new Promise((resolve) => {
    let phase: RunPhase = "loading";
    let timer = 0;

    const arm = (limit: number) => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        current.removeEventListener("message", onMessage);
        current.removeEventListener("error", onError);
        spawnWorker();
        resolve({
          stdout: "",
          stderr:
            phase === "loading"
              ? "Не удалось загрузить Python. Проверь сеть и попробуй ещё раз."
              : "Остановил: программа работала слишком долго. Если внутри бесконечный цикл — поправь его и запусти снова.",
          stopped: phase !== "loading",
        });
      }, limit);
    };

    const finish = (result: RunResult) => {
      window.clearTimeout(timer);
      current.removeEventListener("message", onMessage);
      current.removeEventListener("error", onError);
      resolve(result);
    };

    const onError = () => {
      spawnWorker();
      finish({
        stdout: "",
        stderr: "Не удалось запустить Python. Обнови страницу и попробуй снова.",
        stopped: false,
      });
    };

    const onMessage = (event: MessageEvent<WorkerResponse>) => {
      if (event.data.id !== id) return;
      if (event.data.phase === "done") {
        finish({
          stdout: event.data.stdout,
          stderr: event.data.stderr,
          stopped: false,
        });
        return;
      }
      phase = event.data.phase;
      onPhase(phase);
      arm(phase === "loading" ? LOAD_LIMIT_MS : RUN_LIMIT_MS);
    };

    current.addEventListener("message", onMessage);
    current.addEventListener("error", onError);
    onPhase("loading");
    arm(LOAD_LIMIT_MS);
    current.postMessage({ id, code, indexURL: pyodideIndexUrl() });
  });
}
