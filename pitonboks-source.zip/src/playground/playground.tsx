import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";
import { LoaderCircle, Play, RotateCcw } from "lucide-react";
import { runPython, type RunPhase } from "@/playground/runner";
import { defaultSnippet, snippets } from "@/playground/snippets";

const STORAGE_KEY = "pitonbox-code";

type Output = {
  stdout: string;
  stderr: string;
};

export function Playground() {
  const [code, setCode] = useState(defaultSnippet.code);
  const [activeId, setActiveId] = useState(defaultSnippet.id);
  const [phase, setPhase] = useState<RunPhase | "idle">("idle");
  const [output, setOutput] = useState<Output | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const runLock = useRef(false);
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setCode(saved);
      const match = snippets.find((snippet) => snippet.code === saved);
      setActiveId(match?.id ?? "");
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, code);
  }, [code, hydrated]);

  const lineCount = useMemo(() => Math.max(1, code.split("\n").length), [code]);
  const busy = phase === "loading" || phase === "running";

  async function execute() {
    if (runLock.current) return;
    runLock.current = true;
    setOutput(null);
    setPhase("loading");
    try {
      const result = await runPython(code, setPhase);
      setOutput({ stdout: result.stdout, stderr: result.stderr });
      setPhase("done");
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      outputRef.current?.scrollIntoView({
        block: "nearest",
        behavior: reduce ? "auto" : "smooth",
      });
    } finally {
      runLock.current = false;
    }
  }

  function loadSnippet(id: string) {
    const snippet = snippets.find((item) => item.id === id);
    if (!snippet || busy) return;
    setActiveId(snippet.id);
    setCode(snippet.code);
    setOutput(null);
    setPhase("idle");
  }

  function onEditorKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Tab") {
      event.preventDefault();
      const target = event.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const next = `${code.slice(0, start)}    ${code.slice(end)}`;
      setCode(next);
      setActiveId(snippets.find((snippet) => snippet.code === next)?.id ?? "");
      requestAnimationFrame(() => {
        target.selectionStart = start + 4;
        target.selectionEnd = start + 4;
      });
      return;
    }
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
      event.preventDefault();
      void execute();
    }
  }

  const status = statusLabel(phase, output);

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-4">
          <span
            aria-hidden="true"
            className="grid size-11 shrink-0 place-items-center rounded-lg bg-ink font-sans text-sm text-gold"
          >
            Py
          </span>
          <div className="min-w-0">
            <h1 className="font-display text-3xl leading-none text-balance text-ink">
              Питонбокс
            </h1>
            <p className="mt-1 text-xs text-pretty text-muted">
              Мини-лаборатория: настоящий Python, без установки
            </p>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-4 px-4 py-4 lg:grid-cols-[16rem_minmax(0,1fr)] lg:py-6">
        <section aria-label="Примеры" className="min-w-0">
          <h2 className="mb-2 text-xs tracking-wide text-muted uppercase">Примеры</h2>
          <div className="grid grid-cols-2 gap-2 lg:grid-cols-1">
            {snippets.map((snippet) => {
              const selected = snippet.id === activeId;
              return (
                <button
                  key={snippet.id}
                  type="button"
                  disabled={busy}
                  onClick={() => loadSnippet(snippet.id)}
                  className={
                    "min-h-11 rounded-lg border px-3 py-2 text-left transition-colors " +
                    (selected
                      ? "border-gold bg-ink text-paper"
                      : "border-line bg-sheet text-ink hover:border-moss")
                  }
                >
                  <span className="block text-sm">{snippet.title}</span>
                  <span
                    className={"block text-xs " + (selected ? "text-gold" : "text-muted")}
                  >
                    {snippet.blurb}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        <section className="flex min-w-0 flex-col gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => void execute()}
              disabled={busy}
              className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-gold px-4 text-sm text-ink disabled:opacity-60"
            >
              {busy ? (
                <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
              ) : (
                <Play className="size-4" aria-hidden="true" />
              )}
              {busy ? "Работает" : "Запустить"}
            </button>
            <button
              type="button"
              onClick={() => {
                setOutput(null);
                setPhase("idle");
              }}
              disabled={busy || !output}
              className="inline-flex min-h-11 items-center gap-2 rounded-lg border border-line bg-sheet px-4 text-sm text-ink disabled:opacity-50"
            >
              <RotateCcw className="size-4" aria-hidden="true" />
              Очистить вывод
            </button>
            <p className="text-xs text-muted" role="status">
              {status}
            </p>
          </div>

          <label className="sr-only" htmlFor="code">
            Код на Python
          </label>
          <Editor
            code={code}
            lineCount={lineCount}
            onChange={(next) => {
              setCode(next);
              setActiveId(snippets.find((snippet) => snippet.code === next)?.id ?? "");
            }}
            onKeyDown={onEditorKeyDown}
          />
          <p className="text-xs text-muted">
            Tab ставит четыре пробела. Ctrl+Enter или Cmd+Enter запускает код.
          </p>

          <div
            ref={outputRef}
            aria-live="polite"
            className="min-h-48 overflow-auto rounded-card bg-ink p-4 text-sm leading-6 text-console-fg"
          >
            <p className="mb-2 text-xs tracking-wide text-console-dim uppercase">Вывод</p>
            <ConsoleBody phase={phase} output={output} />
          </div>
        </section>
      </main>
    </div>
  );
}

function Editor({
  code,
  lineCount,
  onChange,
  onKeyDown,
}: {
  code: string;
  lineCount: number;
  onChange: (next: string) => void;
  onKeyDown: (event: KeyboardEvent<HTMLTextAreaElement>) => void;
}) {
  const gutterRef = useRef<HTMLPreElement>(null);
  const numbers = Array.from({ length: lineCount }, (_, index) => String(index + 1)).join("\n");

  return (
    <div className="grid h-72 grid-cols-[2.75rem_minmax(0,1fr)] overflow-hidden rounded-card border border-line bg-sheet lg:h-96">
      <pre
        ref={gutterRef}
        aria-hidden="true"
        className="m-0 overflow-hidden py-3 pr-2 text-right font-sans text-sm leading-6 text-muted"
      >
        {numbers}
      </pre>
      <textarea
        id="code"
        value={code}
        spellCheck={false}
        autoCapitalize="off"
        autoCorrect="off"
        onChange={(event) => onChange(event.target.value)}
        onKeyDown={onKeyDown}
        onScroll={(event) => {
          if (gutterRef.current) {
            gutterRef.current.scrollTop = event.currentTarget.scrollTop;
          }
        }}
        className="h-full w-full resize-none bg-transparent py-3 pr-3 pl-2 font-sans text-sm leading-6 text-ink"
      />
    </div>
  );
}

function ConsoleBody({
  phase,
  output,
}: {
  phase: RunPhase | "idle";
  output: Output | null;
}) {
  if (phase === "loading") {
    return <p className="text-console-dim">Загружаю Python… первый запуск чуть дольше.</p>;
  }
  if (phase === "running" && !output) {
    return <p className="text-console-dim">Считает…</p>;
  }
  if (!output) {
    return (
      <p className="text-console-dim">
        Нажми «Запустить». То, что программа печатает, появится здесь.
      </p>
    );
  }
  const stdout = output.stdout.replace(/\s+$/u, "");
  const stderr = output.stderr.replace(/\s+$/u, "");
  if (!stdout && !stderr) {
    return <p className="text-console-dim">Программа ничего не напечатала.</p>;
  }
  return (
    <div className="space-y-3">
      {stdout ? <pre className="whitespace-pre-wrap break-words">{stdout}</pre> : null}
      {stderr ? (
        <pre className="whitespace-pre-wrap break-words text-gold">{stderr}</pre>
      ) : null}
    </div>
  );
}

function statusLabel(phase: RunPhase | "idle", output: Output | null): string {
  if (phase === "loading") return "Грею интерпретатор";
  if (phase === "running") return "Выполняю";
  if (phase === "done" && output?.stderr.trim()) return "Есть ошибка";
  if (phase === "done") return "Готово";
  return "Готов к запуску";
}
