import{a as e,i as t,n,r,t as i}from"./index-DT84QMSt.js";var a=n(`loader-circle`,[[`path`,{d:`M21 12a9 9 0 1 1-6.219-8.56`,key:`13zald`}]]),o=n(`play`,[[`polygon`,{points:`6 3 20 12 6 21 6 3`,key:`1oa8hb`}]]),s=n(`rotate-ccw`,[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}]]),c=e(t(),1),l=8e3,u=45e3,d=null,f=1;function p(){let e=i(window.location.hostname,window.location.pathname)??``;return`${window.location.origin}${e}/pyodide/`}function m(){return d?.terminate(),d=new Worker(new URL(`/assets/python.worker-DFKBspTD.js`,``+import.meta.url),{type:`module`}),d}function h(e,t){let n=d??m(),r=f++;return new Promise(i=>{let a=`loading`,o=0,s=e=>{window.clearTimeout(o),o=window.setTimeout(()=>{n.removeEventListener(`message`,f),n.removeEventListener(`error`,d),m(),i({stdout:``,stderr:a===`loading`?`Не удалось загрузить Python. Проверь сеть и попробуй ещё раз.`:`Остановил: программа работала слишком долго. Если внутри бесконечный цикл — поправь его и запусти снова.`,stopped:a!==`loading`})},e)},c=e=>{window.clearTimeout(o),n.removeEventListener(`message`,f),n.removeEventListener(`error`,d),i(e)},d=()=>{m(),c({stdout:``,stderr:`Не удалось запустить Python. Обнови страницу и попробуй снова.`,stopped:!1})},f=e=>{e.data.id===r&&(e.data.phase===`done`?c({stdout:e.data.stdout,stderr:e.data.stderr,stopped:!1}):(a=e.data.phase,t(a),s(a===`loading`?u:l)))};n.addEventListener(`message`,f),n.addEventListener(`error`,d),t(`loading`),s(u),n.postMessage({id:r,code:e,indexURL:p()})})}var g=[{id:`hello`,title:`Приветствие`,blurb:`цикл и f-строки`,code:`print("Привет из Питонбокса")

items = ["чай", "код", "вечер"]
for number, item in enumerate(items, start=1):
    print(f"{number}. {item}")

print("Звёзды:")
for count in range(1, 6):
    print("#" * count)
`},{id:`password`,title:`Пароль`,blurb:`secrets из стандартной библиотеки`,code:`import secrets
import string

alphabet = string.ascii_letters + string.digits
password = "".join(secrets.choice(alphabet) for _ in range(14))
print(password)
`},{id:`budget`,title:`Бюджет`,blurb:`сумма и полоски`,code:`expenses = {
    "кофе": 840,
    "метро": 560,
    "обед": 2100,
    "книги": 690,
}

total = sum(expenses.values())
print(f"Всего за неделю: {total} руб.")
print()

for name, amount in sorted(expenses.items(), key=lambda item: -item[1]):
    bar = "#" * max(1, amount // 200)
    print(f"{name:<8} {bar}  {amount}")
`},{id:`fizzbuzz`,title:`FizzBuzz`,blurb:`классика на 20 чисел`,code:`def fizzbuzz(limit):
    words = []
    for number in range(1, limit + 1):
        if number % 15 == 0:
            words.append("FizzBuzz")
        elif number % 3 == 0:
            words.append("Fizz")
        elif number % 5 == 0:
            words.append("Buzz")
        else:
            words.append(str(number))
    return words

print(" ".join(fizzbuzz(20)))
`},{id:`primes`,title:`Простые`,blurb:`решето Эратосфена`,code:`def primes_up_to(limit):
    sieve = [True] * (limit + 1)
    sieve[0:2] = [False, False]
    for number in range(2, int(limit**0.5) + 1):
        if sieve[number]:
            start = number * number
            sieve[start::number] = [False] * len(sieve[start::number])
    return [number for number, ok in enumerate(sieve) if ok]

found = primes_up_to(80)
print("Простые до 80:")
print(", ".join(map(str, found)))
print("Всего:", len(found))
`},{id:`degrees`,title:`Градусы`,blurb:`Цельсий в Фаренгейт`,code:`def celsius_to_fahrenheit(celsius):
    return celsius * 9 / 5 + 32

print(f"{'C':>6} {'F':>8}")
for celsius in range(-10, 35, 5):
    fahrenheit = celsius_to_fahrenheit(celsius)
    print(f"{celsius:>6} {fahrenheit:>8.1f}")
`}],_=g[0],v=r(),y=`pitonbox-code`;function b(){let[e,t]=(0,c.useState)(_.code),[n,r]=(0,c.useState)(_.id),[i,l]=(0,c.useState)(`idle`),[u,d]=(0,c.useState)(null),[f,p]=(0,c.useState)(!1),m=(0,c.useRef)(!1),b=(0,c.useRef)(null);(0,c.useEffect)(()=>{let e=window.localStorage.getItem(y);if(e){t(e);let n=g.find(t=>t.code===e);r(n?.id??``)}p(!0)},[]),(0,c.useEffect)(()=>{f&&window.localStorage.setItem(y,e)},[e,f]);let w=(0,c.useMemo)(()=>Math.max(1,e.split(`
`).length),[e]),T=i===`loading`||i===`running`;async function E(){if(!m.current){m.current=!0,d(null),l(`loading`);try{let t=await h(e,l);d({stdout:t.stdout,stderr:t.stderr}),l(`done`);let n=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches;b.current?.scrollIntoView({block:`nearest`,behavior:n?`auto`:`smooth`})}finally{m.current=!1}}}function D(e){let n=g.find(t=>t.id===e);n&&!T&&(r(n.id),t(n.code),d(null),l(`idle`))}function O(n){if(n.key===`Tab`){n.preventDefault();let i=n.currentTarget,a=i.selectionStart,o=i.selectionEnd,s=`${e.slice(0,a)}    ${e.slice(o)}`;t(s),r(g.find(e=>e.code===s)?.id??``),requestAnimationFrame(()=>{i.selectionStart=a+4,i.selectionEnd=a+4})}else(n.metaKey||n.ctrlKey)&&n.key===`Enter`&&(n.preventDefault(),E())}let k=C(i,u);return(0,v.jsxs)(`div`,{className:`min-h-dvh bg-paper text-ink`,children:[(0,v.jsx)(`header`,{className:`border-b border-line`,children:(0,v.jsxs)(`div`,{className:`mx-auto flex max-w-6xl items-center gap-4 px-4 py-4`,children:[(0,v.jsx)(`span`,{"aria-hidden":`true`,className:`grid size-11 shrink-0 place-items-center rounded-lg bg-ink font-sans text-sm text-gold`,children:`Py`}),(0,v.jsxs)(`div`,{className:`min-w-0`,children:[(0,v.jsx)(`h1`,{className:`font-display text-3xl leading-none text-balance text-ink`,children:`Питонбокс`}),(0,v.jsx)(`p`,{className:`mt-1 text-xs text-pretty text-muted`,children:`Мини-лаборатория: настоящий Python, без установки`})]})]})}),(0,v.jsxs)(`main`,{className:`mx-auto grid max-w-6xl gap-4 px-4 py-4 lg:grid-cols-[16rem_minmax(0,1fr)] lg:py-6`,children:[(0,v.jsxs)(`section`,{"aria-label":`Примеры`,className:`min-w-0`,children:[(0,v.jsx)(`h2`,{className:`mb-2 text-xs tracking-wide text-muted uppercase`,children:`Примеры`}),(0,v.jsx)(`div`,{className:`grid grid-cols-2 gap-2 lg:grid-cols-1`,children:g.map(e=>{let t=e.id===n;return(0,v.jsxs)(`button`,{type:`button`,disabled:T,onClick:()=>D(e.id),className:`min-h-11 rounded-lg border px-3 py-2 text-left transition-colors `+(t?`border-gold bg-ink text-paper`:`border-line bg-sheet text-ink hover:border-moss`),children:[(0,v.jsx)(`span`,{className:`block text-sm`,children:e.title}),(0,v.jsx)(`span`,{className:`block text-xs `+(t?`text-gold`:`text-muted`),children:e.blurb})]},e.id)})})]}),(0,v.jsxs)(`section`,{className:`flex min-w-0 flex-col gap-3`,children:[(0,v.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,v.jsxs)(`button`,{type:`button`,onClick:()=>void E(),disabled:T,className:`inline-flex min-h-11 items-center gap-2 rounded-lg bg-gold px-4 text-sm text-ink disabled:opacity-60`,children:[T?(0,v.jsx)(a,{className:`size-4 animate-spin`,"aria-hidden":`true`}):(0,v.jsx)(o,{className:`size-4`,"aria-hidden":`true`}),T?`Работает`:`Запустить`]}),(0,v.jsxs)(`button`,{type:`button`,onClick:()=>{d(null),l(`idle`)},disabled:T||!u,className:`inline-flex min-h-11 items-center gap-2 rounded-lg border border-line bg-sheet px-4 text-sm text-ink disabled:opacity-50`,children:[(0,v.jsx)(s,{className:`size-4`,"aria-hidden":`true`}),`Очистить вывод`]}),(0,v.jsx)(`p`,{className:`text-xs text-muted`,role:`status`,children:k})]}),(0,v.jsx)(`label`,{className:`sr-only`,htmlFor:`code`,children:`Код на Python`}),(0,v.jsx)(x,{code:e,lineCount:w,onChange:e=>{t(e),r(g.find(t=>t.code===e)?.id??``)},onKeyDown:O}),(0,v.jsx)(`p`,{className:`text-xs text-muted`,children:`Tab ставит четыре пробела. Ctrl+Enter или Cmd+Enter запускает код.`}),(0,v.jsxs)(`div`,{ref:b,"aria-live":`polite`,className:`min-h-48 overflow-auto rounded-card bg-ink p-4 text-sm leading-6 text-console-fg`,children:[(0,v.jsx)(`p`,{className:`mb-2 text-xs tracking-wide text-console-dim uppercase`,children:`Вывод`}),(0,v.jsx)(S,{phase:i,output:u})]})]})]})]})}function x({code:e,lineCount:t,onChange:n,onKeyDown:r}){let i=(0,c.useRef)(null),a=Array.from({length:t},(e,t)=>String(t+1)).join(`
`);return(0,v.jsxs)(`div`,{className:`grid h-72 grid-cols-[2.75rem_minmax(0,1fr)] overflow-hidden rounded-card border border-line bg-sheet lg:h-96`,children:[(0,v.jsx)(`pre`,{ref:i,"aria-hidden":`true`,className:`m-0 overflow-hidden py-3 pr-2 text-right font-sans text-sm leading-6 text-muted`,children:a}),(0,v.jsx)(`textarea`,{id:`code`,value:e,spellCheck:!1,autoCapitalize:`off`,autoCorrect:`off`,onChange:e=>n(e.target.value),onKeyDown:r,onScroll:e=>{i.current&&(i.current.scrollTop=e.currentTarget.scrollTop)},className:`h-full w-full resize-none bg-transparent py-3 pr-3 pl-2 font-sans text-sm leading-6 text-ink`})]})}function S({phase:e,output:t}){if(e===`loading`)return(0,v.jsx)(`p`,{className:`text-console-dim`,children:`Загружаю Python… первый запуск чуть дольше.`});if(e===`running`&&!t)return(0,v.jsx)(`p`,{className:`text-console-dim`,children:`Считает…`});if(!t)return(0,v.jsx)(`p`,{className:`text-console-dim`,children:`Нажми «Запустить». То, что программа печатает, появится здесь.`});let n=t.stdout.replace(/\s+$/u,``),r=t.stderr.replace(/\s+$/u,``);return!n&&!r?(0,v.jsx)(`p`,{className:`text-console-dim`,children:`Программа ничего не напечатала.`}):(0,v.jsxs)(`div`,{className:`space-y-3`,children:[n?(0,v.jsx)(`pre`,{className:`whitespace-pre-wrap break-words`,children:n}):null,r?(0,v.jsx)(`pre`,{className:`whitespace-pre-wrap break-words text-gold`,children:r}):null]})}function C(e,t){return e===`loading`?`Грею интерпретатор`:e===`running`?`Выполняю`:e===`done`&&t?.stderr.trim()?`Есть ошибка`:e===`done`?`Готово`:`Готов к запуску`}var w=b;export{w as component};