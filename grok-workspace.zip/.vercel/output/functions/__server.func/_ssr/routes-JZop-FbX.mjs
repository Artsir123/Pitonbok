import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as LoaderCircle, n as RotateCcw, r as Play } from "../_libs/lucide-react.mjs";
import { n as previewPathPrefix } from "./router-CmQhYvUB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-JZop-FbX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RUN_LIMIT_MS = 8e3;
var LOAD_LIMIT_MS = 45e3;
var worker = null;
var nextId = 1;
function pyodideIndexUrl() {
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
	return `${window.location.origin}${prefix}/pyodide/`;
}
function spawnWorker() {
	worker?.terminate();
	worker = new Worker(new URL("./python.worker.ts", import.meta.url), { type: "module" });
	return worker;
}
function runPython(code, onPhase) {
	const current = worker ?? spawnWorker();
	const id = nextId++;
	return new Promise((resolve) => {
		let phase = "loading";
		let timer = 0;
		const arm = (limit) => {
			window.clearTimeout(timer);
			timer = window.setTimeout(() => {
				current.removeEventListener("message", onMessage);
				current.removeEventListener("error", onError);
				spawnWorker();
				resolve({
					stdout: "",
					stderr: phase === "loading" ? "Не удалось загрузить Python. Проверь сеть и попробуй ещё раз." : "Остановил: программа работала слишком долго. Если внутри бесконечный цикл — поправь его и запусти снова.",
					stopped: phase !== "loading"
				});
			}, limit);
		};
		const finish = (result) => {
			window.clearTimeout(timer);
			current.removeEventListener("message", onMessage);
			current.removeEventListener("error", onError);
			resolve(result);
		};
		const onError = () => {
			spawnWorker();
			finish({
				stdout: "",
				stderr: "Не удалось запустить Python. Обнови страницу и попробуй снова.",
				stopped: false
			});
		};
		const onMessage = (event) => {
			if (event.data.id !== id) return;
			if (event.data.phase === "done") {
				finish({
					stdout: event.data.stdout,
					stderr: event.data.stderr,
					stopped: false
				});
				return;
			}
			phase = event.data.phase;
			onPhase(phase);
			arm(phase === "loading" ? LOAD_LIMIT_MS : RUN_LIMIT_MS);
		};
		current.addEventListener("message", onMessage);
		current.addEventListener("error", onError);
		onPhase("loading");
		arm(LOAD_LIMIT_MS);
		current.postMessage({
			id,
			code,
			indexURL: pyodideIndexUrl()
		});
	});
}
var snippets = [
	{
		id: "hello",
		title: "Приветствие",
		blurb: "цикл и f-строки",
		code: `print("Привет из Питонбокса")

items = ["чай", "код", "вечер"]
for number, item in enumerate(items, start=1):
    print(f"{number}. {item}")

print("Звёзды:")
for count in range(1, 6):
    print("#" * count)
`
	},
	{
		id: "password",
		title: "Пароль",
		blurb: "secrets из стандартной библиотеки",
		code: `import secrets
import string

alphabet = string.ascii_letters + string.digits
password = "".join(secrets.choice(alphabet) for _ in range(14))
print(password)
`
	},
	{
		id: "budget",
		title: "Бюджет",
		blurb: "сумма и полоски",
		code: `expenses = {
    "кофе": 840,
    "метро": 560,
    "обед": 2100,
    "книги": 690,
}

total = sum(expenses.values())
print(f"Всего за неделю: {total} руб.")
print()

for name, amount in sorted(expenses.items(), key=lambda item: -item[1]):
    bar = "#" * max(1, amount // 200)
    print(f"{name:<8} {bar}  {amount}")
`
	},
	{
		id: "fizzbuzz",
		title: "FizzBuzz",
		blurb: "классика на 20 чисел",
		code: `def fizzbuzz(limit):
    words = []
    for number in range(1, limit + 1):
        if number % 15 == 0:
            words.append("FizzBuzz")
        elif number % 3 == 0:
            words.append("Fizz")
        elif number % 5 == 0:
            words.append("Buzz")
        else:
            words.append(str(number))
    return words

print(" ".join(fizzbuzz(20)))
`
	},
	{
		id: "primes",
		title: "Простые",
		blurb: "решето Эратосфена",
		code: `def primes_up_to(limit):
    sieve = [True] * (limit + 1)
    sieve[0:2] = [False, False]
    for number in range(2, int(limit**0.5) + 1):
        if sieve[number]:
            start = number * number
            sieve[start::number] = [False] * len(sieve[start::number])
    return [number for number, ok in enumerate(sieve) if ok]

found = primes_up_to(80)
print("Простые до 80:")
print(", ".join(map(str, found)))
print("Всего:", len(found))
`
	},
	{
		id: "degrees",
		title: "Градусы",
		blurb: "Цельсий в Фаренгейт",
		code: `def celsius_to_fahrenheit(celsius):
    return celsius * 9 / 5 + 32

print(f"{'C':>6} {'F':>8}")
for celsius in range(-10, 35, 5):
    fahrenheit = celsius_to_fahrenheit(celsius)
    print(f"{celsius:>6} {fahrenheit:>8.1f}")
`
	}
];
var defaultSnippet = snippets[0];
var STORAGE_KEY = "pitonbox-code";
function Playground() {
	const [code, setCode] = (0, import_react.useState)(defaultSnippet.code);
	const [activeId, setActiveId] = (0, import_react.useState)(defaultSnippet.id);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [output, setOutput] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const runLock = (0, import_react.useRef)(false);
	const outputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const saved = window.localStorage.getItem(STORAGE_KEY);
		if (saved) {
			setCode(saved);
			const match = snippets.find((snippet) => snippet.code === saved);
			setActiveId(match?.id ?? "");
		}
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		window.localStorage.setItem(STORAGE_KEY, code);
	}, [code, hydrated]);
	const lineCount = (0, import_react.useMemo)(() => Math.max(1, code.split("\n").length), [code]);
	const busy = phase === "loading" || phase === "running";
	async function execute() {
		if (runLock.current) return;
		runLock.current = true;
		setOutput(null);
		setPhase("loading");
		try {
			const result = await runPython(code, setPhase);
			setOutput({
				stdout: result.stdout,
				stderr: result.stderr
			});
			setPhase("done");
			const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			outputRef.current?.scrollIntoView({
				block: "nearest",
				behavior: reduce ? "auto" : "smooth"
			});
		} finally {
			runLock.current = false;
		}
	}
	function loadSnippet(id) {
		const snippet = snippets.find((item) => item.id === id);
		if (!snippet || busy) return;
		setActiveId(snippet.id);
		setCode(snippet.code);
		setOutput(null);
		setPhase("idle");
	}
	function onEditorKeyDown(event) {
		if (event.key === "Tab") {
			event.preventDefault();
			const target = event.currentTarget;
			const start = target.selectionStart;
			const end = target.selectionEnd;
			const next = `${code.slice(0, start)}    ${code.slice(end)}`;
			setCode(next);
			setActiveId(snippets.find((snippet) => snippet.code === next)?.id ?? "");
			requestAnimationFrame(() => {
				target.selectionStart = start + 4;
				target.selectionEnd = start + 4;
			});
			return;
		}
		if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
			event.preventDefault();
			execute();
		}
	}
	const status = statusLabel(phase, output);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-paper text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center gap-4 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": "true",
					className: "grid size-11 shrink-0 place-items-center rounded-lg bg-ink font-sans text-sm text-gold",
					children: "Py"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl leading-none text-balance text-ink",
						children: "Питонбокс"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-pretty text-muted",
						children: "Мини-лаборатория: настоящий Python, без установки"
					})]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 py-4 lg:grid-cols-[16rem_minmax(0,1fr)] lg:py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-label": "Примеры",
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 text-xs tracking-wide text-muted uppercase",
					children: "Примеры"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 lg:grid-cols-1",
					children: snippets.map((snippet) => {
						const selected = snippet.id === activeId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy,
							onClick: () => loadSnippet(snippet.id),
							className: "min-h-11 rounded-lg border px-3 py-2 text-left transition-colors " + (selected ? "border-gold bg-ink text-paper" : "border-line bg-sheet text-ink hover:border-moss"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm",
								children: snippet.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs " + (selected ? "text-gold" : "text-muted"),
								children: snippet.blurb
							})]
						}, snippet.id);
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-w-0 flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void execute(),
								disabled: busy,
								className: "inline-flex min-h-11 items-center gap-2 rounded-lg bg-gold px-4 text-sm text-ink disabled:opacity-60",
								children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "size-4 animate-spin",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									className: "size-4",
									"aria-hidden": "true"
								}), busy ? "Работает" : "Запустить"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setOutput(null);
									setPhase("idle");
								},
								disabled: busy || !output,
								className: "inline-flex min-h-11 items-center gap-2 rounded-lg border border-line bg-sheet px-4 text-sm text-ink disabled:opacity-50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Очистить вывод"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								role: "status",
								children: status
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "code",
						children: "Код на Python"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
						code,
						lineCount,
						onChange: (next) => {
							setCode(next);
							setActiveId(snippets.find((snippet) => snippet.code === next)?.id ?? "");
						},
						onKeyDown: onEditorKeyDown
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Tab ставит четыре пробела. Ctrl+Enter или Cmd+Enter запускает код."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: outputRef,
						"aria-live": "polite",
						className: "min-h-48 overflow-auto rounded-card bg-ink p-4 text-sm leading-6 text-console-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs tracking-wide text-console-dim uppercase",
							children: "Вывод"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleBody, {
							phase,
							output
						})]
					})
				]
			})]
		})]
	});
}
function Editor({ code, lineCount, onChange, onKeyDown }) {
	const gutterRef = (0, import_react.useRef)(null);
	const numbers = Array.from({ length: lineCount }, (_, index) => String(index + 1)).join("\n");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid h-72 grid-cols-[2.75rem_minmax(0,1fr)] overflow-hidden rounded-card border border-line bg-sheet lg:h-96",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			ref: gutterRef,
			"aria-hidden": "true",
			className: "m-0 overflow-hidden py-3 pr-2 text-right font-sans text-sm leading-6 text-muted",
			children: numbers
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			id: "code",
			value: code,
			spellCheck: false,
			autoCapitalize: "off",
			autoCorrect: "off",
			onChange: (event) => onChange(event.target.value),
			onKeyDown,
			onScroll: (event) => {
				if (gutterRef.current) gutterRef.current.scrollTop = event.currentTarget.scrollTop;
			},
			className: "h-full w-full resize-none bg-transparent py-3 pr-3 pl-2 font-sans text-sm leading-6 text-ink"
		})]
	});
}
function ConsoleBody({ phase, output }) {
	if (phase === "loading") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-console-dim",
		children: "Загружаю Python… первый запуск чуть дольше."
	});
	if (phase === "running" && !output) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-console-dim",
		children: "Считает…"
	});
	if (!output) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-console-dim",
		children: "Нажми «Запустить». То, что программа печатает, появится здесь."
	});
	const stdout = output.stdout.replace(/\s+$/u, "");
	const stderr = output.stderr.replace(/\s+$/u, "");
	if (!stdout && !stderr) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-console-dim",
		children: "Программа ничего не напечатала."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [stdout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "whitespace-pre-wrap break-words",
			children: stdout
		}) : null, stderr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "whitespace-pre-wrap break-words text-gold",
			children: stderr
		}) : null]
	});
}
function statusLabel(phase, output) {
	if (phase === "loading") return "Грею интерпретатор";
	if (phase === "running") return "Выполняю";
	if (phase === "done" && output?.stderr.trim()) return "Есть ошибка";
	if (phase === "done") return "Готово";
	return "Готов к запуску";
}
var SplitComponent = Playground;
//#endregion
export { SplitComponent as component };
